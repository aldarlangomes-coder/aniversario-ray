console.log("Site de aniversário carregado 🎉");

// Exemplo: tocar música automaticamente
// const audio = new Audio("caminho_da_sua_musica.mp3");
// audio.play();